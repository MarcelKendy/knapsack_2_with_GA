import random
import time
import os

# Classe que define um item candidato à mochila:
class Item:
    def __init__(self, id, value, weight):
        if value <= 0 or value > 100:
            raise ValueError("O valor deve ser > 0 && <= 100.")
        if weight <= 0 or weight > 100:
            raise ValueError("O peso deve ser > 0 && <= 100.")        
        self.id = id
        self.value = value
        self.weight = weight
        self.efficiency = round(value / weight, 2)  

# Algoritmo para escolha e distribuição dos itens. Prioriza os itens de maior eficiência e os coloca no knapsack mais vazio:
def knapsackEfficient(items, max_weight):
    # Inicialmente faz um sort desc pela eficiência dos itens:
    items.sort(key=lambda x: x.efficiency, reverse=True)    
    knapsack1, knapsack2, ub_value, total_value1, total_value2, total_weight1, total_weight2 = [], [], 0, 0, 0, 0, 0    
    # Faz o loop pelos itens e enquanto adquire alguns dados para o relatório, se possível, os colocam no knapsack mais vazio: 
    for item in items:
        ub_value += item.value
        if total_weight1 + item.weight <= max_weight and total_weight1 <= total_weight2:
            knapsack1.append(item)
            total_weight1 += item.weight
            total_value1 += item.value
        elif total_weight2 + item.weight <= max_weight:
            knapsack2.append(item)
            total_weight2 += item.weight
            total_value2 += item.value

    return knapsack1, knapsack2, ub_value, total_value1, total_value2, total_weight1, total_weight2

# Função para gerar casos de teste. Sempre dobra o número de itens gerados para o próximo teste, começando com 10. 
# Escreve os casos teste e seus resultados em arquivos no diretório do código, e substitui os resultados antigos caso existirem. 
# Parâmetros: 
#   qtt: Quantidade de casos a serem gerados,
#   min_value: Número mínimo para definir os atributos valor e peso dos itens,
#   max_value: Número máximo para definir os atributos valor e peso dos itens,
#   knapsacks_total_capacity: Porcentagem em decimal da capacidade de carga de todas as mochilas juntas em relação ao peso total de todos itens candidatos
def generateNRunTestCases(qtt = 10, min_value = 1, max_value = 100, knapsacks_total_capacity = 0.75):
    for i in range(qtt):
        num_items = qtt * (2 ** i)
        items = []
        input_filename = f"{num_items}.txt"
        result_filename = f"{num_items}-result.txt"        
        if os.path.exists(input_filename):
            os.remove(input_filename)
        if os.path.exists(result_filename):
            os.remove(result_filename)
            
        # Gerando a quantidade determinada de itens teste e guardando-os no arquivo e no array:
        with open(f"{num_items}.txt", "w") as f:
            f.write("Id: Valor, Peso:\n")
            for i in range(num_items):
                id = i + 1
                value = random.randint(min_value, max_value)
                weight = random.randint(min_value, max_value)                
                items.append(Item(id, value, weight))
                f.write(f"{id}: {value}, {weight}\n")        
        ub_weight = sum(item.weight for item in items)
        max_weight = int((knapsacks_total_capacity * ub_weight) / 2)
        
        # Chamando o algoritmo para o caso teste e medindo seu tempo de execução:
        start_time = time.perf_counter()
        knapsack1, knapsack2, ub_value, total_value1, total_value2, total_weight1, total_weight2 = knapsackEfficient(items, max_weight)
        end_time = time.perf_counter()
        total_weight = total_weight1 + total_weight2
        total_value = total_value1 + total_value2
        total_items = len(knapsack1) + len(knapsack2)
        elapsed_time = (end_time - start_time) * 1000
        # Escrevendo os resultados em um arquivo:        
        with open(f"{num_items}-result.txt", "w") as f:
            f.write(f"Tempo de execução: {elapsed_time:.6f} milissegundos\n")                        
            f.write("Especificações:\n")
            f.write(f"Quantidade total de itens (UB): {num_items}\n")
            f.write(f"Valor total dos itens (UB): {ub_value}\n")
            f.write(f"Peso total dos itens (UB): {ub_weight}\n")   
            f.write(f"Capacidade total de carga ({knapsacks_total_capacity * 100}% do peso total): {max_weight * 2}\n")         
            f.write(f"Peso máximo de cada mochila: {max_weight}\n")
            f.write("-----------------------------\n")
            f.write("Resultados Gerais:\n")
            f.write(f"Número de itens carregados: {total_items}\n")
            f.write(f"Valor total adquirido: {total_value}\n")
            f.write(f"Peso total carregado: {total_weight}\n")                        
            f.write(f"Porcentagem do Upper Bound na quantidade de itens: {round((total_items / num_items) * 100, 2)}%\n")
            f.write(f"Porcentagem do Upper Bound no valor adquirido: {round((total_value / ub_value) * 100, 2)}%\n")
            f.write(f"Porcentagem do Upper Bound no peso carregado: {round((total_weight / ub_weight) * 100, 2)}%\n")            
            f.write("-----------------------------\n")
            f.write("Resultados por Mochila:\n")
            f.write(f"Número de itens na mochila 1: {len(knapsack1)}\n")
            f.write(f"Valor da mochila 1: {total_value1}\n")
            f.write(f"Peso da mochila 1: {total_weight1}\n")
            f.write(f"Eficiência da mochila 1: {round(total_value1 / total_weight1, 2) if total_weight1 > 0 else 0}\n")            
            f.write("-----------------------------\n")
            f.write(f"Número de itens na mochila 2: {len(knapsack2)}\n")
            f.write(f"Valor da mochila 2: {total_value2}\n")
            f.write(f"Peso da mochila 2: {total_weight2}\n")            
            f.write(f"Eficiência da mochila 2: {round(total_value2 / total_weight2, 2) if total_weight2 > 0 else 0}\n")                    
            f.write("-----------------------------\n")                        
            f.write("Itens selecionados na mochila 1:\n")
            for item in knapsack1:
                f.write(f"Id: {item.id}, Valor: {item.value}, Peso: {item.weight}, Eficiência: {item.efficiency}\n")
            f.write("-----------------------------\n")
            f.write("Itens selecionados na mochila 2:\n")
            for item in knapsack2:
                f.write(f"Id: {item.id}, Valor: {item.value}, Peso: {item.weight}, Eficiência: {item.efficiency}\n")

# Geração de casos de teste e execução do algoritmo
generateNRunTestCases()
