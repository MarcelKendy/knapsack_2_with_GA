import random
import time
import os

# Classe que define um item candidato à mochila:
class Item:
    def __init__(self, id, value, weight):
        if value <= 0 or value > 100:
            raise ValueError("O valor deve ser > 0 && <= 100.")
        if weight <= 0 or weight > 100:
            raise ValueError("O peso deve ser > 0 && <= 100.")        
        self.id = id
        self.value = value
        self.weight = weight
        self.efficiency = round(value / weight, 2)  

# Função para avaliar a solução gerada pelo Algoritmo Genético:
def evaluate_solution(solution, items, max_weight):
    total_weight1, total_weight2, total_value = 0, 0, 0
    iterations = len(solution) // 2 
    for i in range(iterations):
        knapsack2_index = len(solution) - 1 - i
        if solution[i] == 1 and solution[knapsack2_index] == 1:
            if random.randint(1, 2) == 1:
                solution[knapsack2_index] = 0
            else:
                solution[i] = 0
        if solution[i] == 1:
            total_weight1 += items[i].weight
            total_value += items[i].value
        elif solution[knapsack2_index] == 1:
            total_weight2 += items[i].weight
            total_value += items[i].value
        if total_weight1 > max_weight or total_weight2 > max_weight:
            return 0
    return total_value

# Função de crossover:
def crossover(parent1, parent2):
    crossover_point = random.randint(1, len(parent1) - 1)
    child1 = parent1[:crossover_point] + parent2[crossover_point:]
    child2 = parent2[:crossover_point] + parent1[crossover_point:]
    return child1, child2

# Função de mutação:
def mutate(solution, mutation_rate=1):
    for i in range(len(solution)):
        if random.randint(0, 100) <= mutation_rate:
            solution[i] = 1 - solution[i]  # Troca entre 0 e 1

# Função principal do Algoritmo Genético:
def knapsackEfficient(items, max_weight, population_size=1000, generations=100):
    num_items = len(items)
    genes = num_items * 2
    population = [[random.randint(0, 1) for _ in range(genes)] for _ in range(population_size)]
    best_solution = None
    best_value = 0

    for _ in range(generations):
        population = sorted(population, key=lambda x: evaluate_solution(x, items, max_weight), reverse=True)
        next_generation = population[:population_size // 2]  # Mantém a metade mais apta

        while len(next_generation) < population_size:
            parent1 = random.choice(population[:50])
            parent2 = random.choice(population[:50])
            child1, child2 = crossover(parent1, parent2)
            mutate(child1)
            mutate(child2)
            next_generation.append(child1)
            next_generation.append(child2)

        # Ordena a nova geração incluindo os filhos
        population = sorted(next_generation, key=lambda x: evaluate_solution(x, items, max_weight), reverse=True)
        # Avalia o melhor indivíduo da nova geração
        current_best_value = evaluate_solution(population[0], items, max_weight)
        
        if current_best_value > best_value:
            best_value = current_best_value
            best_solution = population[0]
    knapsack1, knapsack2 = [], []
    total_value1, total_value2, total_weight1, total_weight2 = 0, 0, 0, 0
    for i in range(num_items):        
        knapsack2_index = len(best_solution) - 1 - i        
        if best_solution[i] == 1:
            knapsack1.append(items[i])
            total_weight1 += items[i].weight
            total_value1 += items[i].value
        elif best_solution[knapsack2_index] == 1:
            knapsack2.append(items[i])
            total_weight2 += items[i].weight
            total_value2 += items[i].value
    ub_value = sum(item.value for item in items)
    return knapsack1, knapsack2, ub_value, total_value1, total_value2, total_weight1, total_weight2

# Função para gerar casos de teste. Sempre dobra o número de itens gerados para o próximo teste, começando com 10. 
# Escreve os casos teste e seus resultados em arquivos no diretório do código, e substitui os resultados antigos caso existirem. 
# Parâmetros: 
#   qtt: Quantidade de casos a serem gerados,
#   min_value: Número mínimo para definir os atributos valor e peso dos itens,
#   max_value: Número máximo para definir os atributos valor e peso dos itens,
#   knapsacks_total_capacity: Porcentagem em decimal da capacidade de carga de todas as mochilas juntas em relação ao peso total de todos itens candidatos
def generateNRunTestCases(qtt = 10, min_value = 1, max_value = 100, knapsacks_total_capacity = 0.75):
    for i in range(qtt):
        num_items = 10 * (2 ** i)
        items = []
        input_filename = f"{num_items}.txt"
        result_filename = f"{num_items}-result.txt"        
        if os.path.exists(input_filename):
            os.remove(input_filename)
        if os.path.exists(result_filename):
            os.remove(result_filename)
            
        # Gerando a quantidade determinada de itens teste e guardando-os no arquivo e no array:
        with open(f"{num_items}.txt", "w") as f:
            f.write("Id: Valor, Peso:\n")
            for i in range(num_items):
                id = i + 1
                value = random.randint(min_value, max_value)
                weight = random.randint(min_value, max_value)                
                items.append(Item(id, value, weight))
                f.write(f"{id}: {value}, {weight}\n")        
        ub_weight = sum(item.weight for item in items)
        max_weight = int((knapsacks_total_capacity * ub_weight) / 2)
        
        # Chamando o algoritmo para o caso teste e medindo seu tempo de execução:
        start_time = time.perf_counter()
        knapsack1, knapsack2, ub_value, total_value1, total_value2, total_weight1, total_weight2 = knapsackEfficient(items, max_weight)
        end_time = time.perf_counter()
        total_weight = total_weight1 + total_weight2
        total_value = total_value1 + total_value2
        total_items = len(knapsack1) + len(knapsack2)
        elapsed_time = (end_time - start_time) * 1000
        # Escrevendo os resultados em um arquivo:        
        with open(f"{num_items}-result.txt", "w") as f:
            f.write(f"Tempo de execução: {elapsed_time:.6f} milissegundos\n")                        
            f.write("Especificações:\n")
            f.write(f"Quantidade total de itens (UB): {num_items}\n")
            f.write(f"Valor total dos itens (UB): {ub_value}\n")
            f.write(f"Peso total dos itens (UB): {ub_weight}\n")   
            f.write(f"Capacidade total de carga ({knapsacks_total_capacity * 100}% do peso total): {max_weight * 2}\n")         
            f.write(f"Peso máximo de cada mochila: {max_weight}\n")
            f.write("-----------------------------\n")
            f.write("Resultados Gerais:\n")
            f.write(f"Número de itens carregados: {total_items}\n")
            f.write(f"Valor total adquirido: {total_value}\n")
            f.write(f"Peso total carregado: {total_weight}\n")                        
            f.write(f"Porcentagem do Upper Bound na quantidade de itens: {round((total_items / num_items) * 100, 2)}%\n")
            f.write(f"Porcentagem do Upper Bound no valor adquirido: {round((total_value / ub_value) * 100, 2)}%\n")
            f.write(f"Porcentagem do Upper Bound no peso carregado: {round((total_weight / ub_weight) * 100, 2)}%\n")            
            f.write("-----------------------------\n")
            f.write("Resultados por Mochila:\n")
            f.write(f"Número de itens na mochila 1: {len(knapsack1)}\n")
            f.write(f"Valor da mochila 1: {total_value1}\n")
            f.write(f"Peso da mochila 1: {total_weight1}\n")
            f.write(f"Eficiência da mochila 1: {round(total_value1 / total_weight1, 2) if total_weight1 > 0 else 0}\n")            
            f.write("-----------------------------\n")
            f.write(f"Número de itens na mochila 2: {len(knapsack2)}\n")
            f.write(f"Valor da mochila 2: {total_value2}\n")
            f.write(f"Peso da mochila 2: {total_weight2}\n")            
            f.write(f"Eficiência da mochila 2: {round(total_value2 / total_weight2, 2) if total_weight2 > 0 else 0}\n")                    
            f.write("-----------------------------\n")                        
            f.write("Itens selecionados na mochila 1:\n")
            for item in knapsack1:
                f.write(f"Id: {item.id}, Valor: {item.value}, Peso: {item.weight}, Eficiência: {item.efficiency}\n")
            f.write("-----------------------------\n")
            f.write("Itens selecionados na mochila 2:\n")
            for item in knapsack2:
                f.write(f"Id: {item.id}, Valor: {item.value}, Peso: {item.weight}, Eficiência: {item.efficiency}\n")

# Geração de casos de teste e execução do algoritmo
generateNRunTestCases()
